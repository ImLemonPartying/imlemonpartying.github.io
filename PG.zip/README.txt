Failure is not an option.  
You've made it this far.
You must look within.
It isn't that hard.